
import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect, useRef } from 'react';
import { Booking } from '../types';

interface NotificationContextType {
  newBookingAlertsSoundEnabled: boolean;
  toggleNewBookingAlertsSound: () => void;
  triggerNewBookingNotification: (currentAvailableBookings: Booking[]) => void;
  isAudioUnlocked: boolean; 
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

const NOTIFICATION_SOUND_ENABLED_KEY = 'driverlink_notification_sound_enabled';

export const NotificationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [newBookingAlertsSoundEnabled, setNewBookingAlertsSoundEnabled] = useState<boolean>(() => {
    const storedValue = localStorage.getItem(NOTIFICATION_SOUND_ENABLED_KEY);
    const initialValue = storedValue ? JSON.parse(storedValue) : true; // Default to true
    console.log(`NotificationProvider Mounted: Initial sound setting from localStorage is ${initialValue}. isAudioUnlocked is initially false.`);
    return initialValue;
  });

  const [isAudioUnlocked, setIsAudioUnlocked] = useState<boolean>(false);
  const seenAvailableBookingIdsRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    localStorage.setItem(NOTIFICATION_SOUND_ENABLED_KEY, JSON.stringify(newBookingAlertsSoundEnabled));
  }, [newBookingAlertsSoundEnabled]);

  const attemptAudioUnlock = useCallback(async (triggeredBy: 'global' | 'settings_toggle'): Promise<boolean> => {
    if (isAudioUnlocked) {
      console.log(`AttemptAudioUnlock (${triggeredBy}): Audio already unlocked.`);
      return true;
    }

    const audioElement = document.getElementById('notificationSound') as HTMLAudioElement;
    if (!audioElement) {
      console.warn(`AttemptAudioUnlock (${triggeredBy}): Notification sound element not found.`);
      return false;
    }
    if (!audioElement.src || audioElement.src === window.location.href) { // Check if src is missing or points to the page itself
      console.warn(`AttemptAudioUnlock (${triggeredBy}): Audio element 'src' is missing or invalid. Current src: ${audioElement.src}`);
      return false;
    }
    // readyState 0: HAVE_NOTHING, 1: HAVE_METADATA, 2: HAVE_CURRENT_DATA, 3: HAVE_FUTURE_DATA, 4: HAVE_ENOUGH_DATA
    console.log(`AttemptAudioUnlock (${triggeredBy}): Attempting... AudioEl readyState: ${audioElement.readyState}, muted: ${audioElement.muted}, volume: ${audioElement.volume}, src: ${audioElement.src}`);
    
    // It's possible for play() to be called before metadata is loaded if preload="none" or network is slow.
    // While preload="auto" is set, a check doesn't hurt.
    if (audioElement.readyState < HTMLMediaElement.HAVE_METADATA) {
         console.warn(`AttemptAudioUnlock (${triggeredBy}): Audio metadata not yet loaded (readyState: ${audioElement.readyState}). Waiting for 'loadedmetadata'.`);
         // Optionally, wait for loadedmetadata, but for unlock, direct play attempt is usually okay if user-initiated.
    }

    const originalMutedState = audioElement.muted;
    const originalVolume = audioElement.volume;
    
    audioElement.muted = false; 
    audioElement.volume = 0.01; // Play at a very low volume for unlock

    try {
      await audioElement.play();
      audioElement.pause(); 
      audioElement.currentTime = 0; 
      setIsAudioUnlocked(true); 
      console.log(`AttemptAudioUnlock (${triggeredBy}): Audio context successfully unlocked by user interaction.`);
      return true;
    } catch (error) {
      console.warn(`AttemptAudioUnlock (${triggeredBy}): Attempt to unlock audio context failed. User interaction (click/tap page, or toggle sound in settings) might still be needed. Error:`, error);
      return false;
    } finally {
      // Restore original state if needed, though for unlock it might not be critical
      audioElement.volume = originalVolume; 
      audioElement.muted = originalMutedState;
    }
  }, [isAudioUnlocked]); // isAudioUnlocked is a dependency to re-evaluate this callback if needed, though it's mainly for the check at the start.

  // Effect for global audio unlock attempt on first user interaction
  useEffect(() => {
    const handleGlobalInteraction = () => {
      // console.log("Global user interaction detected (click/touchstart).");
      attemptAudioUnlock('global');
    };

    if (!isAudioUnlocked) {
      // console.log("Global Unlock Effect: Setting up one-time listeners for audio unlock (isAudioUnlocked is false).");
      document.addEventListener('click', handleGlobalInteraction, { once: true, capture: true }); // Using capture might help in some complex DOMs
      document.addEventListener('touchstart', handleGlobalInteraction, { once: true, capture: true });
    } else {
      // console.log("Global Unlock Effect: Audio is already unlocked, listeners not added/are removed by cleanup.");
    }

    return () => { 
      // console.log("Global Unlock Effect: Cleaning up one-time listeners (due to isAudioUnlocked change or component unmount).");
      document.removeEventListener('click', handleGlobalInteraction, {capture: true});
      document.removeEventListener('touchstart', handleGlobalInteraction, {capture: true});
    };
  }, [isAudioUnlocked, attemptAudioUnlock]); 

  const internalPlaySound = useCallback(async () => {
    const audioElement = document.getElementById('notificationSound') as HTMLAudioElement;
    if (!audioElement) {
      console.warn("InternalPlaySound: Notification sound element not found.");
      return;
    }
    if (!audioElement.src || audioElement.src === window.location.href) {
      console.warn(`InternalPlaySound: Audio element 'src' is missing or invalid. Cannot play. Current src: ${audioElement.src}`);
      return;
    }
    if (audioElement.readyState < HTMLMediaElement.HAVE_ENOUGH_DATA) {
        console.warn(`InternalPlaySound: Not enough data to play sound (readyState: ${audioElement.readyState}). Playback might be choppy or fail.`);
    }

    console.log(`InternalPlaySound: Attempting to play... AudioEl readyState: ${audioElement.readyState}, muted: ${audioElement.muted}, volume: ${audioElement.volume}`);

    try {
      audioElement.muted = false; 
      audioElement.volume = 1.0;  
      audioElement.currentTime = 0; // Rewind to start
      await audioElement.play();
      console.log("InternalPlaySound: Notification sound played successfully.");
    } catch (error) {
      console.error("InternalPlaySound: Error playing notification sound:", error);
    }
  }, []);

  const toggleNewBookingAlertsSound = useCallback(async () => {
    const willBeEnabled = !newBookingAlertsSoundEnabled;
    setNewBookingAlertsSoundEnabled(willBeEnabled);

    if (willBeEnabled && !isAudioUnlocked) {
      console.log("ToggleSoundSetting: Sound explicitly enabled by user, attempting to unlock audio.");
      await attemptAudioUnlock('settings_toggle');
    }
  }, [newBookingAlertsSoundEnabled, isAudioUnlocked, attemptAudioUnlock]);

  const triggerNewBookingNotification = useCallback((currentAvailableBookings: Booking[]) => {
    console.log(`TriggerNotification: Called. Sound enabled: ${newBookingAlertsSoundEnabled}, Audio unlocked: ${isAudioUnlocked}`);
    if (!newBookingAlertsSoundEnabled) {
      // If sound is globally disabled, clear seen bookings so if it's re-enabled, all current ones are "new"
      seenAvailableBookingIdsRef.current.clear(); 
      // console.log("TriggerNotification: Sound alerts are disabled in settings. Skipping.");
      return;
    }
    
    if (!isAudioUnlocked) { 
      console.warn("TriggerNotification: Notification sound for new booking skipped: Audio not yet unlocked by user interaction (e.g. enabling sound in settings or clicking/tapping the page).");
    }

    let newBookingFound = false;
    const currentBookingIds = new Set<string>();

    currentAvailableBookings.forEach(booking => {
      currentBookingIds.add(booking.id);
      if (!seenAvailableBookingIdsRef.current.has(booking.id)) {
        newBookingFound = true;
        // console.log(`TriggerNotification: New available booking detected: ${booking.id}`);
        seenAvailableBookingIdsRef.current.add(booking.id);
      }
    });
    
    // Clean up seen IDs that are no longer in the available list
    seenAvailableBookingIdsRef.current.forEach(seenId => {
      if (!currentBookingIds.has(seenId)) {
        // console.log(`TriggerNotification: Removing stale seen booking ID: ${seenId}`);
        seenAvailableBookingIdsRef.current.delete(seenId);
      }
    });

    if (newBookingFound && isAudioUnlocked) { 
      console.log("TriggerNotification: New booking(s) found and audio IS UNLOCKED. Attempting to play sound.");
      internalPlaySound();
    } else if (newBookingFound && !isAudioUnlocked) {
      // This case is already covered by the warning at the top of the function.
      // console.log("TriggerNotification: New booking(s) found, but audio is NOT UNLOCKED. Sound skipped as per browser policy.");
    } else if (!newBookingFound) {
      // console.log("TriggerNotification: No new available bookings detected since last check.");
    }

  }, [newBookingAlertsSoundEnabled, isAudioUnlocked, internalPlaySound]);

  return (
    <NotificationContext.Provider value={{ newBookingAlertsSoundEnabled, toggleNewBookingAlertsSound, triggerNewBookingNotification, isAudioUnlocked }}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotification = (): NotificationContextType => {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
};
