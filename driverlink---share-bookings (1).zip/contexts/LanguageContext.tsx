
import React, { createContext, useState, useContext, ReactNode, useCallback } from 'react';
import { translations, Locale, Translations } from '../translations';

interface LanguageContextType {
  languageCode: Locale;
  setLanguageCode: (code: Locale) => void;
  t: (key: string, params?: Record<string, string | number>) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [languageCode, setLanguageCode] = useState<Locale>('en'); // Default to English

  const t = useCallback((key: string, params?: Record<string, string | number>): string => {
    let text = translations[languageCode][key] || translations.en[key] || key;
    if (params) {
      Object.keys(params).forEach(paramKey => {
        const regex = new RegExp(`{${paramKey}}`, 'g');
        text = text.replace(regex, String(params[paramKey]));
      });
    }
    return text;
  }, [languageCode]);

  return (
    <LanguageContext.Provider value={{ languageCode, setLanguageCode, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
