import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';
import { User } from '../types';
// import { CURRENT_DRIVER_ID } from '../constants'; // No longer needed for mock user
import { useLanguage } from './LanguageContext';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (email: string, password_raw: string) => Promise<User>; // password_raw to indicate it's not stored
  signup: (name: string, email: string, password_raw: string) => Promise<User>;
  logout: () => Promise<void>;
  isLoading: boolean;
  authError: string | null;
  setAuthError: (error: string | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user store - starts empty for "live" data
const MOCK_USERS: User[] = [];
// In a real app, passwords would be hashed and checked on a server.
// For mock, we'll just check email. Password check is trivial for mock.
const MOCK_PASSWORDS: Record<string, string> = {};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true); // Start true for initial check
  const [authError, setAuthError] = useState<string | null>(null);
  const { t } = useLanguage();

  // Simulate checking for an existing session (e.g., from localStorage)
  useEffect(() => {
    const checkSession = async () => {
      setIsLoading(true);
      const storedUser = localStorage.getItem('driverlink_current_user');
      if (storedUser) {
        try {
          const user: User = JSON.parse(storedUser);
          // Optional: Validate user session with a mock backend call
          setCurrentUser(user);
        } catch (e) {
          localStorage.removeItem('driverlink_current_user');
        }
      }
      setIsLoading(false);
    };
    checkSession();
  }, []);

  const login = useCallback(async (email: string, password_raw: string): Promise<User> => {
    setIsLoading(true);
    setAuthError(null);
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const foundUser = MOCK_USERS.find(u => u.email.toLowerCase() === email.toLowerCase());
        if (foundUser && MOCK_PASSWORDS[foundUser.email] === password_raw) {
          setCurrentUser(foundUser);
          localStorage.setItem('driverlink_current_user', JSON.stringify(foundUser));
          setIsLoading(false);
          resolve(foundUser);
        } else {
          setAuthError(t('authInvalidCredentials'));
          setIsLoading(false);
          reject(new Error(t('authInvalidCredentials')));
        }
      }, 1000);
    });
  }, [t]);

  const signup = useCallback(async (name: string, email: string, password_raw: string): Promise<User> => {
    setIsLoading(true);
    setAuthError(null);
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (MOCK_USERS.find(u => u.email.toLowerCase() === email.toLowerCase())) {
          setAuthError(t('authEmailExists'));
          setIsLoading(false);
          reject(new Error(t('authEmailExists')));
          return;
        }
        
        const nextIdNumber = MOCK_USERS.length + 1; 
        const formattedIdNumber = String(nextIdNumber).padStart(3, '0');
        const newUserId = `DRV-${formattedIdNumber}`;

        const newUser: User = {
          id: newUserId,
          name,
          email,
        };
        MOCK_USERS.push(newUser); 
        MOCK_PASSWORDS[newUser.email] = password_raw; 

        setCurrentUser(newUser);
        localStorage.setItem('driverlink_current_user', JSON.stringify(newUser));
        setIsLoading(false);
        resolve(newUser);
      }, 1000);
    });
  }, [t]);

  const logout = useCallback(async () => {
    setIsLoading(true);
    setAuthError(null);
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        setCurrentUser(null);
        localStorage.removeItem('driverlink_current_user');
        setIsLoading(false);
        resolve();
      }, 500);
    });
  }, []);

  return (
    <AuthContext.Provider value={{ 
        currentUser, 
        isAuthenticated: !!currentUser, 
        login, 
        signup, 
        logout, 
        isLoading,
        authError,
        setAuthError
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};