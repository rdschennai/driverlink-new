

import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Ensure API_KEY is available in the environment
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("Gemini API key not found. Please set the API_KEY environment variable.");
  // Potentially throw an error or handle this state gracefully in the UI
}

// const ai = new GoogleGenAI({ apiKey: API_KEY! }); // Non-null assertion as we check above
// Initialize ai only if API_KEY is present, to avoid errors if key is missing and service is imported but not used.
let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
   console.warn("Gemini Service: API key not configured. Gemini features will be unavailable.");
}


// Example function for other AI features (if any) could go here in the future
// export const someOtherTextFunction = async (prompt: string): Promise<string> => {
//   if (!ai) throw new Error("Gemini AI client not initialized. API Key might be missing.");
//   try {
//     const response: GenerateContentResponse = await ai.models.generateContent({
//       model: 'gemini-2.5-flash-preview-04-17', // Or another appropriate model
//       contents: prompt,
//     });
//     const text = response.text;
//     if (text) {
//       return text;
//     } else {
//       throw new Error("Failed to generate content.");
//     }
//   } catch (error) {
//     console.error("Error in someOtherTextFunction:", error);
//     throw error;
//   }
// };

export const checkApiKey = (): boolean => {
  if (!API_KEY) {
    console.warn("Gemini Service: API key not configured.");
    return false;
  }
  if (!ai) {
    console.warn("Gemini Service: AI client not initialized despite API_KEY presence (should not happen).");
    return false;
  }
  return true;
};