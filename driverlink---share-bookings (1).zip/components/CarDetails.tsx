import React from 'react';
import { Car } from '../types';

interface CarDetailsProps {
  car: Car;
}

const CarDetails: React.FC<CarDetailsProps> = ({ car }) => {
  return (
    <div className="bg-slate-700/50 p-6 rounded-lg shadow-lg text-slate-100">
      <h2 className="text-3xl font-bold mb-2 text-sky-400">{car.make} {car.model} <span className="text-2xl text-slate-400">({car.year})</span></h2>
      <img 
        src={car.imageUrl} 
        alt={`${car.make} ${car.model}`} 
        className="w-full h-64 object-cover rounded-lg mb-6 shadow-md border-2 border-slate-600"
      />
      <p className="text-slate-300 mb-6 text-lg leading-relaxed">{car.description}</p>
      
      <h3 className="text-xl font-semibold mb-3 text-sky-500">Key Specifications:</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
        {car.specs.map((spec, index) => (
          <div key={index} className="flex justify-between py-2 border-b border-slate-600">
            <span className="font-medium text-slate-300">{spec.label}:</span>
            <span className="text-slate-200">{spec.value}</span>
          </div>
        ))}
        <div className="flex justify-between py-2 border-b border-slate-600">
            <span className="font-medium text-slate-300">Color:</span>
            <span className="text-slate-200">{car.color}</span>
        </div>
      </div>
    </div>
  );
};

export default CarDetails;
