
import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext'; // Import useAuth

// Helper components, defined outside ProfilePage to ensure stability
const ProfileInfoDisplay: React.FC<{labelKey: string, value: string | undefined, t: (key: string) => string}> = ({labelKey, value, t}) => (
    <div>
      <label className="block text-sm font-medium text-gray-500">{t(labelKey)}</label>
      <p className="mt-1 text-lg text-gray-800 break-words">{value || '-'}</p>
    </div>
);

const ProfileInfoInput: React.FC<{labelKey: string, value: string, onChange: (val: string) => void, type?: string, id: string, t: (key: string) => string}> =
    ({labelKey, value, onChange, type = "text", id, t}) => (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-700">{t(labelKey)}</label>
      <input
        type={type}
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full p-3 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
      />
    </div>
);


const ProfilePage: React.FC = () => {
  const { t } = useLanguage();
  const { currentUser } = useAuth(); // Get currentUser from AuthContext
  const [isEditing, setIsEditing] = useState<boolean>(false);
  
  // State for editable fields. Initialized from currentUser or defaults.
  const [name, setName] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>("(555) 123-4567"); // Example, not from currentUser yet

  // State for form inputs when editing
  const [editName, setEditName] = useState<string>('');
  const [editEmail, setEditEmail] = useState<string>('');
  const [editPhone, setEditPhone] = useState<string>('');

  // Effect to populate state from currentUser when it changes or on initial load
  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || '');
      setEmail(currentUser.email || '');
      // If phone were part of currentUser: setPhone(currentUser.phone || '');
      
      if (!isEditing) {
        setEditName(currentUser.name || '');
        setEditEmail(currentUser.email || '');
        setEditPhone(phone); // Keep current local phone for edit
      }
    }
  }, [currentUser, isEditing, phone]);

   // Sync edit fields when switching to edit mode or if currentUser details changed while not editing
  useEffect(() => {
    if (isEditing) {
      setEditName(name);
      setEditEmail(email);
      setEditPhone(phone); 
    }
  }, [isEditing, name, email, phone]);


  const handleEditToggle = () => {
    if (isEditing) { // Means "Cancel" was effectively hit by toggling off edit mode without saving
      // Reset edit fields to persisted/current state
      setEditName(name);
      setEditEmail(email);
      setEditPhone(phone);
    } else { // Switching to edit mode
      // Ensure edit fields are up-to-date with current state
      setEditName(name);
      setEditEmail(email);
      setEditPhone(phone);
    }
    setIsEditing(!isEditing);
  };

  const handleSave = () => {
    // Here, you would typically send data to a backend.
    // For this mock, we just update the local "display" state.
    setName(editName);
    setEmail(editEmail);
    setPhone(editPhone); 
    
    // In a real app, if name/email changed, you might update currentUser in AuthContext
    // or trigger a refetch of user data.
    // For now, AuthContext's currentUser.name/email will be out of sync with display
    // until next login or if we manually update it.

    setIsEditing(false);
  };

  const handleCancel = () => {
    // Reset edit fields to current display state and exit edit mode
    setEditName(name);
    setEditEmail(email);
    setEditPhone(phone);
    setIsEditing(false);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
      <div className="flex justify-between items-center mb-6 border-b border-gray-300 pb-3">
        <h2 className="text-2xl font-semibold text-sky-600">
          {t('profilePageTitle')}
        </h2>
        {!isEditing && (
          <button
            onClick={handleEditToggle}
            className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded-lg shadow hover:shadow-md transition-colors duration-300 text-sm"
            aria-label={t('profilePageEditButton')}
          >
            {t('profilePageEditButton')}
          </button>
        )}
      </div>
      
      <div className="space-y-6 text-gray-700">
        <div className="flex flex-col items-center space-y-2 mb-6"> {/* Reduced space-y if needed */}
            {/* Profile photo placeholder removed */}
            <p className="text-xl font-semibold text-gray-800">{isEditing ? editName : name || t('profilePageNameLabel')}</p>
        </div>


        {isEditing ? (
          <>
            <ProfileInfoDisplay t={t} labelKey="profilePageDriverIdLabel" value={currentUser?.id} />
            <ProfileInfoInput t={t} labelKey="profilePageNameLabel" value={editName} onChange={setEditName} id="editName" />
            <ProfileInfoInput t={t} labelKey="profilePageEmailLabel" value={editEmail} onChange={setEditEmail} type="email" id="editEmail" />
            <ProfileInfoInput t={t} labelKey="profilePagePhoneLabel" value={editPhone} onChange={setEditPhone} type="tel" id="editPhone" />
          </>
        ) : (
          <>
            <ProfileInfoDisplay t={t} labelKey="profilePageDriverIdLabel" value={currentUser?.id} />
            <ProfileInfoDisplay t={t} labelKey="profilePageNameLabel" value={name} />
            <ProfileInfoDisplay t={t} labelKey="profilePageEmailLabel" value={email} />
            <ProfileInfoDisplay t={t} labelKey="profilePagePhoneLabel" value={phone} />
            <div>
                <label className="block text-sm font-medium text-gray-500">{t('profilePageMemberSinceLabel')}</label>
                <p className="mt-1 text-lg text-gray-800">{t('profilePageMemberSinceDate')}</p> 
            </div>
          </>
        )}
        
        {isEditing && (
          <div className="flex justify-end space-x-3 mt-8 pt-4 border-t border-gray-200">
            <button
              onClick={handleCancel}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors border border-gray-300"
            >
              {t('profilePageCancel')}
            </button>
            <button
              onClick={handleSave}
              className="px-4 py-2 text-sm font-medium text-white bg-sky-500 hover:bg-sky-600 rounded-lg transition-colors shadow hover:shadow-md"
            >
              {t('profilePageSaveChanges')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;
