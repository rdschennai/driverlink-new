import React, { useState, useEffect, useRef } from 'react';
import { Booking, BookingStatus } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

interface BookingItemProps {
  booking: Booking;
  listType: 'personal' | 'available-shared' | 'my-offered' | 'my-active-rides' | 'history';
  activeUserId?: string; // Updated to accept undefined
  onOffer?: (bookingId: string) => void;
  onClaim?: (bookingId: string) => void;
  onAssignToSelf?: (bookingId: string) => void;
  onCancelOffer?: (bookingId: string) => void;
  onEdit?: (booking: Booking) => void;
  onConfirmRide?: (bookingId: string) => void;
  onStartTrip?: (bookingId: string) => void;
  onUpdateToOnTrip?: (bookingId: string) => void; 
  onEndTrip?: (bookingId: string) => void;
  onCompleteRide?: (bookingId: string) => void;
  onCancelBooking?: (bookingId: string) => void;
}

const BookingItem: React.FC<BookingItemProps> = ({ 
  booking, listType, activeUserId,
  onOffer, onClaim, onAssignToSelf, onCancelOffer, onEdit,
  onConfirmRide, onStartTrip, onUpdateToOnTrip, onEndTrip, onCompleteRide,
  onCancelBooking
}) => {
  const { t } = useLanguage();
  const { id, clientName, pickupLocation, dropoffLocation, dateTime, notes, status, originalDriverId, claimedByDriverId } = booking;

  const [showAssignDropdown, setShowAssignDropdown] = useState(false);
  const assignButtonRef = useRef<HTMLDivElement>(null);

  const formattedDateTime = new Date(dateTime).toLocaleString(undefined, {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: true
  });

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (assignButtonRef.current && !assignButtonRef.current.contains(event.target as Node)) {
        setShowAssignDropdown(false);
      }
    };
    if (showAssignDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showAssignDropdown]);

  const getStatusPill = () => {
    let bgColor = 'bg-gray-200'; 
    let textColor = 'text-gray-700'; 
    let displayTextKey: string;
    let params: Record<string, string> | undefined = undefined;

    switch (status) {
      case BookingStatus.PERSONAL:
         bgColor = 'bg-blue-100'; textColor = 'text-blue-700';
         displayTextKey = "bookingStatusPersonal";
        break;
      case BookingStatus.OFFERED:
        bgColor = 'bg-yellow-100'; textColor = 'text-yellow-700';
        if (originalDriverId === activeUserId) { 
          displayTextKey = "bookingStatusYouShared"; 
        } else {
          displayTextKey = `bookingStatusOfferedBy`;
          params = { driverId: originalDriverId?.slice(-4) || 'N/A' };
        }
        break;
      case BookingStatus.TAKEN_BY_OTHER:
        bgColor = 'bg-orange-100'; textColor = 'text-orange-700';
        displayTextKey = `bookingStatusTakenBy`;
        params = { driverId: claimedByDriverId?.slice(-4) || 'N/A' };
        break;
      case BookingStatus.ASSIGNED:
        bgColor = 'bg-teal-100'; textColor = 'text-teal-700';
        displayTextKey = "bookingStatusAssigned";
        break;
      case BookingStatus.CONFIRMED:
        bgColor = 'bg-sky-100'; textColor = 'text-sky-700';
        displayTextKey = "bookingStatusConfirmed";
        break;
      case BookingStatus.TRIP_STARTED: 
        bgColor = 'bg-indigo-100'; textColor = 'text-indigo-700';
        displayTextKey = "bookingStatusTripStarted"; 
        break;
      case BookingStatus.ON_TRIP:
        bgColor = 'bg-purple-100'; textColor = 'text-purple-700';
        displayTextKey = "bookingStatusOnTrip";
        break;
      case BookingStatus.TRIP_ENDED:
        bgColor = 'bg-pink-100'; textColor = 'text-pink-700';
        displayTextKey = "bookingStatusTripEnded";
        break;
      case BookingStatus.COMPLETED:
        bgColor = 'bg-green-100'; textColor = 'text-green-700';
        displayTextKey = "bookingStatusCompleted";
        break;
      case BookingStatus.CANCELLED:
        bgColor = 'bg-red-100'; textColor = 'text-red-700';
        displayTextKey = "bookingStatusCancelled";
        break;
      default:
        displayTextKey = status; 
    }
     return <span className={`px-2 py-1 text-xs font-semibold rounded-full ${bgColor} ${textColor}`}>{t(displayTextKey, params)}</span>;
  };
  
  const canBeCancelled = onCancelBooking && activeUserId && (
    (status === BookingStatus.PERSONAL && originalDriverId === activeUserId) || 
    (status === BookingStatus.OFFERED && originalDriverId === activeUserId) || 
    (claimedByDriverId === activeUserId && [BookingStatus.ASSIGNED, BookingStatus.CONFIRMED].includes(status)) 
  );

  const canEdit = onEdit && activeUserId && 
                  originalDriverId === activeUserId && 
                  status !== BookingStatus.COMPLETED &&
                  status !== BookingStatus.CANCELLED &&
                  status !== BookingStatus.TAKEN_BY_OTHER;

  const handleAssignToNetwork = () => {
    if (onOffer) {
      onOffer(id);
    }
    setShowAssignDropdown(false);
  };

  const handleAssignToSelfClick = () => {
    if (onAssignToSelf) {
      onAssignToSelf(id);
    }
    setShowAssignDropdown(false);
  };

  const showAssignButton = listType === 'personal' && status === BookingStatus.PERSONAL && (onOffer || onAssignToSelf) && activeUserId && originalDriverId === activeUserId;

  return (
    <article className="bg-white p-5 rounded-lg shadow-md flex flex-col justify-between hover:shadow-lg transition-shadow duration-300 border border-gray-200" aria-labelledby={`booking-client-${id}`}>
      <div>
        <div className="flex justify-between items-start mb-2">
            <h3 id={`booking-client-${id}`} className="text-xl font-semibold text-sky-600">{clientName}</h3>
            {getStatusPill()}
        </div>
        <p className="text-sm text-gray-600 mb-1"><strong className="text-gray-700">{t('bookingItemTimeLabel')}</strong> {formattedDateTime}</p>
        <p className="text-sm text-gray-600 mb-1"><strong className="text-gray-700">{t('bookingItemFromLabel')}</strong> {pickupLocation}</p>
        {booking.dropoffLocation && <p className="text-sm text-gray-600 mb-3"><strong className="text-gray-700">{t('bookingItemToLabel')}</strong> {dropoffLocation}</p>}
        {notes && <p className="text-sm bg-gray-100 p-2 rounded-md text-gray-700 mb-3 border border-gray-200"><strong className="text-gray-700">{t('bookingItemNotesLabel')}</strong> {notes}</p>}
      </div>
      <div className="mt-4 pt-4 border-t border-gray-200 flex flex-wrap gap-2 justify-end items-center">
        {showAssignButton && (
          <div className="relative" ref={assignButtonRef}>
            <button
              onClick={() => setShowAssignDropdown(!showAssignDropdown)}
              className="bg-green-500 hover:bg-green-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors flex items-center"
              aria-haspopup="true"
              aria-expanded={showAssignDropdown}
              aria-label={`${t('bookingItemAssign')} ${clientName}`}
            >
              {t('bookingItemAssign')}
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={`w-4 h-4 ml-1 transition-transform duration-200 ${showAssignDropdown ? 'rotate-180' : ''}`}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
              </svg>
            </button>
            {showAssignDropdown && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 z-10 py-1">
                {onOffer && (
                  <button
                    onClick={handleAssignToNetwork}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                    role="menuitem"
                  >
                    {t('bookingItemAssignToNetwork')}
                  </button>
                )}
                {onAssignToSelf && (
                  <button
                    onClick={handleAssignToSelfClick}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                    role="menuitem"
                  >
                    {t('bookingItemAssignToSelf')}
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {listType === 'available-shared' && status === BookingStatus.OFFERED && onClaim && (
          <button
            onClick={() => onClaim(id)}
            className="bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors"
            aria-label={`${t('bookingItemAccept')} ${clientName}`}
          >
            {t('bookingItemAccept')}
          </button>
        )}
        {listType === 'my-offered' && status === BookingStatus.OFFERED && onCancelOffer && activeUserId && originalDriverId === activeUserId && ( 
           <button
            onClick={() => onCancelOffer(id)}
            className="bg-red-500 hover:bg-red-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors"
            aria-label={`${t('bookingItemCancelOffer')} ${clientName}`}
          >
            {t('bookingItemCancelOffer')}
          </button>
        )}

        {listType === 'my-active-rides' && activeUserId && claimedByDriverId === activeUserId && status === BookingStatus.ASSIGNED && onConfirmRide && ( 
          <button onClick={() => onConfirmRide(id)} className="bg-teal-500 hover:bg-teal-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors">{t('bookingItemConfirmRide')}</button>
        )}
        {listType === 'my-active-rides' && activeUserId && claimedByDriverId === activeUserId && status === BookingStatus.CONFIRMED && onStartTrip && ( 
          <button onClick={() => onStartTrip(id)} className="bg-sky-500 hover:bg-sky-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors">{t('bookingItemStartTrip')}</button>
        )}
        {listType === 'my-active-rides' && activeUserId && claimedByDriverId === activeUserId && status === BookingStatus.ON_TRIP && onEndTrip && ( 
          <button onClick={() => onEndTrip(id)} className="bg-purple-500 hover:bg-purple-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors">{t('bookingItemEndTrip')}</button>
        )}
        {listType === 'my-active-rides' && activeUserId && claimedByDriverId === activeUserId && status === BookingStatus.TRIP_ENDED && onCompleteRide && ( 
          <button onClick={() => onCompleteRide(id)} className="bg-pink-500 hover:bg-pink-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors">{t('bookingItemCompleteRide')}</button>
        )}
        
        {canEdit && (
           <button
            onClick={() => onEdit(booking)}
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 text-sm font-medium py-2 px-3 rounded-md transition-colors border border-gray-300"
            aria-label={`${t('bookingItemEdit')} ${clientName}`}
          >
            {t('bookingItemEdit')}
          </button>
        )}

        {canBeCancelled && (
           <button
            onClick={() => onCancelBooking && onCancelBooking(id)}
            className="bg-red-500 hover:bg-red-600 text-white text-sm font-medium py-2 px-3 rounded-md transition-colors"
            aria-label={`${t('bookingItemCancelBooking')} ${clientName}`}
          >
            {t('bookingItemCancelBooking')}
          </button>
        )}
      </div>
    </article>
  );
};

export default BookingItem;