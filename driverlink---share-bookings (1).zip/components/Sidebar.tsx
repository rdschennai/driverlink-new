
import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext'; // Import useAuth
import { View } from '../types'; 

interface SidebarProps {
  activeView: View;
  setActiveView: (view: View) => void; 
  isMobileOpen: boolean;
  setIsMobileOpen: (isOpen: boolean) => void;
}

interface NavItemConfig {
  id: View;
  translationKey: string;
  icon: JSX.Element;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, isMobileOpen, setIsMobileOpen }) => {
  const { t } = useLanguage();
  const { logout, isLoading: isAuthLoading } = useAuth(); // Get logout function and loading state

  const navItems: NavItemConfig[] = [
    {
      id: 'dashboard',
      translationKey: 'sidebarDashboard',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-3">
          <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6A2.25 2.25 0 016 3.75h2.25A2.25 2.25 0 0110.5 6v2.25a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25V6zM3.75 15.75A2.25 2.25 0 016 13.5h2.25a2.25 2.25 0 012.25 2.25V18a2.25 2.25 0 01-2.25 2.25H6a2.25 2.25 0 01-2.25-2.25v-2.25zM13.5 6a2.25 2.25 0 012.25-2.25H18A2.25 2.25 0 0120.25 6v2.25A2.25 2.25 0 0118 10.5h-2.25A2.25 2.25 0 0113.5 8.25V6zM13.5 15.75a2.25 2.25 0 012.25-2.25H18a2.25 2.25 0 012.25 2.25V18A2.25 2.25 0 0118 20.25h-2.25A2.25 2.25 0 0113.5 18v-2.25z" />
        </svg>
      ),
    },
    {
      id: 'profile',
      translationKey: 'sidebarProfile',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-3">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
        </svg>
      ),
    },
    {
      id: 'history',
      translationKey: 'sidebarBookingHistory',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-3">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
        </svg>
      ),
    },
    {
      id: 'settings',
      translationKey: 'sidebarSettings',
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-3">
          <path strokeLinecap="round" strokeLinejoin="round" d="M10.343 3.94c.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11C20.482 2.528 21 3.226 21 4s-.518 1.472-1.11 1.77C18.982 6.072 18.51 6.77 18.51 7.5s.47 1.428 1.11 1.73c.64.3 1.11 1 1.11 1.77s-.518 1.472-1.11 1.77c-.64.3-1.11 1-1.11 1.77s.518 1.472 1.11 1.77c.64.3 1.11 1 1.11 1.77s-.518 1.472-1.11 1.77c-.64.3-1.11 1-1.11 1.77s.518 1.472 1.11 1.77c.64.3 1.11 1 1.11 1.77s-.518 1.472-1.11 1.77c-.64.3-1.11 1-1.11 1.77s.518 1.472 1.11 1.77c.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11h-.09a1.02 1.02 0 00-1.02 1.02c0 .542.47 1.02 1.02 1.02s1.02-.47 1.02-1.02c0-.542-.47-1.02-1.02-1.02zm-7.072-3.072c.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11.55-.09 1.007-.56 1.11-1.11.09-.542.56-1.007 1.11-.11C13.518 2.528 13 3.226 13 4s.518 1.472 1.11 1.77c.64.3 1.11 1 1.11 1.77s-.518 1.472-1.11 1.77c-.64.3-1.11 1-1.11 1.77s.518 1.472 1.11 1.77c.64.3 1.11 1 1.11 1.77s-.518 1.472-1.11 1.77c-.64.3-1.11 1-1.11 1.77s.518 1.472 1.11 1.77c.64.3 1.11 1 1.11 1.77s-.518 1.472-1.11 1.77c-.64.3-1.11 1-1.11 1.77s.518 1.472 1.11 1.77c.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11.55.09 1.007.56 1.11 1.11.09.542.56 1.007 1.11.11h-.09a1.02 1.02 0 00-1.02 1.02c0 .542.47 1.02 1.02 1.02s1.02-.47 1.02-1.02c0-.542-.47-1.02-1.02-1.02zM12 15.75a3.75 3.75 0 100-7.5 3.75 3.75 0 000 7.5z" />
        </svg>
      ),
    },
  ];

  const handleLogout = async () => {
    try {
      await logout();
      setActiveView('login'); // Redirect to login page after logout
      setIsMobileOpen(false); // Close mobile sidebar if open
    } catch (error) {
      console.error("Logout failed:", error);
      // Optionally show an error message to the user
      alert("Logout failed. Please try again.");
    }
  };


  return (
    <aside 
      className={`fixed inset-y-0 left-0 z-40 w-64 bg-white shadow-lg transition-transform duration-300 ease-in-out transform border-r border-gray-200 flex flex-col ${
        isMobileOpen ? 'translate-x-0' : '-translate-x-full'
      } md:translate-x-0`}
      aria-label="Sidebar Menu"
    >
      <div className="flex-grow px-3 py-4 overflow-y-auto pt-20"> 
        <button
          className="absolute top-4 right-4 p-2 text-gray-500 hover:text-sky-600 md:hidden"
          onClick={() => setIsMobileOpen(false)}
          aria-label={t('sidebarCloseMenu')} // Updated translation key
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
        <ul className="space-y-2 font-medium">
          {navItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => {
                  setActiveView(item.id); 
                  // setIsMobileOpen(false); // Already handled by handleViewChange in App.tsx
                }}
                disabled={isAuthLoading} // Disable nav items during auth operations
                className={`flex items-center p-3 rounded-lg w-full text-left transition-colors duration-150 ease-in-out
                  ${activeView === item.id 
                    ? 'bg-sky-500 text-white shadow-sm' 
                    : 'text-gray-700 hover:bg-gray-100 hover:text-sky-600'
                  }
                  ${isAuthLoading ? 'opacity-50 cursor-not-allowed' : ''}
                  `}
                aria-current={activeView === item.id ? 'page' : undefined}
              >
                {item.icon}
                <span className="ml-1">{t(item.translationKey)}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
      <div className="px-3 py-4 mt-auto border-t border-gray-200">
        <button
          onClick={handleLogout}
          disabled={isAuthLoading} // Disable logout button during auth operations
          className={`flex items-center p-3 rounded-lg w-full text-left text-gray-700 hover:bg-gray-100 hover:text-red-600 transition-colors duration-150 ease-in-out font-medium
            ${isAuthLoading ? 'opacity-50 cursor-not-allowed' : ''}
          `}
          aria-label={t('sidebarLogout')}
        >
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-3">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" />
          </svg>
          <span className="ml-1">{isAuthLoading && activeView !== 'login' && activeView !== 'signup' ? t('authLoggingOut') : t('sidebarLogout')}</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;