import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';

interface ScenarioInputProps {
  scenario: string;
  onScenarioChange: (value: string) => void;
  onSubmit: () => void;
  isLoading: boolean;
  starters: string[];
  onStarterClick: (starter: string) => void;
}

const ScenarioInput: React.FC<ScenarioInputProps> = ({ scenario, onScenarioChange, onSubmit, isLoading, starters, onStarterClick }) => {
  return (
    <div className="space-y-4 mb-6">
      <div>
        <label htmlFor="scenario" className="block text-lg font-medium text-sky-400 mb-2">
          Describe Your Dream Drive Scenario:
        </label>
        <textarea
          id="scenario"
          rows={3}
          value={scenario}
          onChange={(e) => onScenarioChange(e.target.value)}
          placeholder="e.g., cruising along a coastal highway at sunset, or tackling a snowy mountain pass..."
          className="w-full p-3 bg-slate-600 text-slate-100 border border-slate-500 rounded-lg shadow-sm focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors"
          disabled={isLoading}
          aria-describedby="scenario-starters-description"
        />
      </div>

      {starters && starters.length > 0 && (
        <div className="mt-2">
          <p id="scenario-starters-description" className="text-sm text-slate-400 mb-2">Or try one of these ideas:</p>
          <div className="flex flex-wrap gap-2">
            {starters.map((starter, index) => (
              <button
                key={index}
                type="button"
                onClick={() => onStarterClick(starter)}
                disabled={isLoading}
                className="px-3 py-1.5 text-xs sm:text-sm bg-slate-600 hover:bg-slate-500 text-sky-300 rounded-md transition-colors duration-150 ease-in-out disabled:opacity-70 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-opacity-50"
                aria-label={`Use scenario: ${starter}`}
              >
                {starter}
              </button>
            ))}
          </div>
        </div>
      )}

      <button
        onClick={onSubmit}
        disabled={isLoading || !scenario.trim()}
        className="w-full bg-gradient-to-r from-sky-500 to-blue-600 hover:from-sky-600 hover:to-blue-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
        aria-label="Generate dream drive image based on the described scenario"
      >
        {isLoading ? (
          <>
            <LoadingSpinner />
            Generating Image...
          </>
        ) : (
          <>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5 mr-2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
            </svg>
            Generate Dream Drive Image
          </>
        )}
      </button>
    </div>
  );
};

export default ScenarioInput;