
import React, { useState, FormEvent } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { LoadingSpinner } from './LoadingSpinner';
import { View } from '../types';

interface SignupPageProps {
  setActiveView: (view: View) => void;
}

const SignupPage: React.FC<SignupPageProps> = ({ setActiveView }) => {
  const { signup, isLoading, authError, setAuthError } = useAuth();
  const { t } = useLanguage();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [showEmailExistsPrompt, setShowEmailExistsPrompt] = useState<boolean>(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setAuthError(null);
    setShowEmailExistsPrompt(false);

    if (!name.trim() || !email.trim() || !password.trim() || !confirmPassword.trim()) {
      setFormError(t('authFieldRequired'));
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
        setFormError(t('authInvalidEmail'));
        return;
    }
    if (password.length < 6) {
        setFormError(t('authPasswordTooShort'));
        return;
    }
    if (password !== confirmPassword) {
      setFormError(t('authPasswordMismatch'));
      return;
    }

    try {
      await signup(name, email, password);
      // Successful signup is handled by App.tsx observing isAuthenticated
    } catch (error: any) {
      // Check if the error message from AuthContext is for existing email
      if (error && error.message === t('authEmailExists')) {
        setShowEmailExistsPrompt(true);
        // We don't setAuthError here as the prompt handles this specific case
      } else {
        // For other errors, setAuthError as usual
        // authError is set by useAuth hook if error is not 'authEmailExists'
      }
    }
  };

  const handleGoToLogin = () => {
    setAuthError(null);
    setFormError(null);
    setShowEmailExistsPrompt(false);
    setActiveView('login');
  };

  const handleResetPassword = () => {
    alert(t('resetPasswordFeatureComingSoon'));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-2xl">
        <h1 className="text-3xl font-bold text-sky-600 text-center mb-2">{t('appName')}</h1>
        <h2 className="text-xl text-gray-700 text-center mb-8">{t('signupPageTitle')}</h2>

        {showEmailExistsPrompt ? (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6 rounded-md" role="alert">
            <p className="font-bold">{t('authEmailExists')}</p>
            <p>{t('authEmailExistsSuggestLoginOrReset')}</p>
            <div className="mt-3 flex gap-x-2">
              <button
                onClick={handleGoToLogin}
                className="text-sm bg-sky-500 hover:bg-sky-600 text-white font-semibold py-1.5 px-3 rounded-md transition-colors"
              >
                {t('loginButton')}
              </button>
              <button
                onClick={handleResetPassword}
                className="text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold py-1.5 px-3 rounded-md transition-colors border border-gray-300"
              >
                {t('resetPasswordLinkText')}
              </button>
            </div>
          </div>
        ) : (authError || formError) && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
            <p className="font-bold">{t('errorTitle')}</p>
            <p>{authError || formError}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
              {t('signupNameLabel')} <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-3 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              aria-required="true"
              autoComplete="name"
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              {t('signupEmailLabel')} <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              aria-required="true"
              autoComplete="email"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
              {t('signupPasswordLabel')} <span className="text-red-500">*</span>
            </label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              aria-required="true"
              autoComplete="new-password"
            />
          </div>
          <div>
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
              {t('signupConfirmPasswordLabel')} <span className="text-red-500">*</span>
            </label>
            <input
              type="password"
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="w-full p-3 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              aria-required="true"
              autoComplete="new-password"
            />
          </div>
          
          <button
            type="submit"
            disabled={isLoading || showEmailExistsPrompt}
            className="w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-4 rounded-lg shadow hover:shadow-md transition-all duration-300 ease-in-out flex items-center justify-center disabled:opacity-70"
          >
            {isLoading ? <LoadingSpinner size="sm" color="text-white" /> : t('signupButton')}
          </button>
        </form>

        <p className="mt-8 text-center text-sm text-gray-600">
          {t('signupHaveAccount')}{' '}
          <button
            onClick={handleGoToLogin} // Re-use the same handler for clarity
            className="font-medium text-sky-600 hover:text-sky-500 hover:underline focus:outline-none focus:ring-2 focus:ring-sky-500 rounded"
          >
            {t('signupLoginLink')}
          </button>
        </p>
      </div>
       <footer className="text-center py-8 text-sm text-gray-500">
        {t('footerText')}
      </footer>
    </div>
  );
};

export default SignupPage;
