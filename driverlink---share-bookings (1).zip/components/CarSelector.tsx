import React from 'react';
import { Car } from '../types';

interface CarSelectorProps {
  cars: Car[];
  onSelectCar: (car: Car) => void;
  selectedCarId?: string;
}

const CarSelector: React.FC<CarSelectorProps> = ({ cars, onSelectCar, selectedCarId }) => {
  return (
    <div className="space-y-4">
      {cars.map((car) => (
        <button
          key={car.id}
          onClick={() => onSelectCar(car)}
          className={`w-full text-left p-4 rounded-lg transition-all duration-200 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-sky-500
            ${selectedCarId === car.id 
              ? 'bg-sky-600 shadow-lg ring-2 ring-sky-400' 
              : 'bg-slate-700 hover:bg-slate-600 shadow-md'
            }`}
        >
          <div className="flex items-center space-x-4">
            <img src={car.imageUrl} alt={`${car.make} ${car.model}`} className="w-20 h-16 object-cover rounded-md shadow-sm" />
            <div>
              <h3 className={`text-lg font-semibold ${selectedCarId === car.id ? 'text-white' : 'text-slate-100'}`}>
                {car.make} {car.model}
              </h3>
              <p className={`text-sm ${selectedCarId === car.id ? 'text-sky-200' : 'text-slate-400'}`}>{car.year}</p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
};

export default CarSelector;
