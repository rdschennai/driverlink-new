
import React, { useState, FormEvent } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';
import { LoadingSpinner } from './LoadingSpinner';
import { View } from '../types';

interface LoginPageProps {
  setActiveView: (view: View) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ setActiveView }) => {
  const { login, isLoading, authError, setAuthError } = useAuth();
  const { t } = useLanguage();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setAuthError(null);

    if (!email.trim() || !password.trim()) {
      setFormError(t('authFieldRequired'));
      return;
    }
    // Basic email validation
    if (!/\S+@\S+\.\S+/.test(email)) {
        setFormError(t('authInvalidEmail'));
        return;
    }

    try {
      await login(email, password);
      // Successful login is handled by App.tsx observing isAuthenticated
      // No need to setActiveView here as App.tsx will do it.
    } catch (error) {
      // authError is set by useAuth hook
    }
  };

  const handleForgotPassword = () => {
    alert(t('resetPasswordFeatureComingSoon'));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <div className="w-full max-w-md bg-white p-8 rounded-xl shadow-2xl">
        <h1 className="text-3xl font-bold text-sky-600 text-center mb-2">{t('appName')}</h1>
        <h2 className="text-xl text-gray-700 text-center mb-8">{t('loginPageTitle')}</h2>

        {(authError || formError) && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded-md" role="alert">
            <p className="font-bold">{t('errorTitle')}</p>
            <p>{authError || formError}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
              {t('loginEmailLabel')} <span className="text-red-500">*</span>
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full p-3 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              aria-required="true"
              autoComplete="email"
            />
          </div>
          <div>
            <div className="flex justify-between items-center">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                {t('loginPasswordLabel')} <span className="text-red-500">*</span>
              </label>
              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-xs sm:text-sm font-medium text-sky-600 hover:text-sky-500 hover:underline focus:outline-none focus:ring-1 focus:ring-sky-500 rounded px-1"
              >
                {t('loginForgotPasswordPrompt')}
              </button>
            </div>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-3 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              required
              aria-required="true"
              autoComplete="current-password"
            />
          </div>
          
          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-4 rounded-lg shadow hover:shadow-md transition-all duration-300 ease-in-out flex items-center justify-center disabled:opacity-70"
          >
            {isLoading ? <LoadingSpinner size="sm" color="text-white" /> : t('loginButton')}
          </button>
        </form>

        <p className="mt-8 text-center text-sm text-gray-600">
          {t('loginNoAccount')}{' '}
          <button
            onClick={() => { setAuthError(null); setFormError(null); setActiveView('signup');}}
            className="font-medium text-sky-600 hover:text-sky-500 hover:underline focus:outline-none focus:ring-2 focus:ring-sky-500 rounded"
          >
            {t('loginSignUpLink')}
          </button>
        </p>
      </div>
      <footer className="text-center py-8 text-sm text-gray-500">
        {t('footerText')}
      </footer>
    </div>
  );
};

export default LoginPage;
