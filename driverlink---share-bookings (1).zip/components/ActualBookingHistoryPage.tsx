import React from 'react';
import { Booking } from '../types';
import BookingList from './BookingList';
import { useLanguage } from '../contexts/LanguageContext';

interface ActualBookingHistoryPageProps {
  bookings: Booking[];
  onEdit?: (booking: Booking) => void; 
  activeUserId?: string; // Updated to accept undefined
}

const ActualBookingHistoryPage: React.FC<ActualBookingHistoryPageProps> = ({ bookings, onEdit, activeUserId }) => {
  const { t } = useLanguage();
  return (
    <div className="bg-white p-4 sm:p-6 rounded-lg shadow-lg border border-gray-200">
      <h2 className="text-2xl font-semibold text-sky-600 mb-6 border-b border-gray-300 pb-3">
        {t('bookingHistoryTitle')} 
        <span className="text-lg text-gray-500 ml-2">{t('bookingHistorySubTitle')}</span>
      </h2>
      
      {bookings && bookings.length > 0 ? (
        <BookingList
          title={t('bookingHistoryTitle')} 
          bookings={bookings}
          listType="history" 
          activeUserId={activeUserId} 
          onEdit={onEdit} 
        />
      ) : (
        <div className="text-center text-gray-500 py-8">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto mb-4 text-gray-400">
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.03 1.123 0 1.131.094 1.976 1.057 1.976 2.192V7.5M12 14.25v-6.375M5.25 9h13.5m-13.5 3h13.5m-13.5 3h13.5M3.75 6a3 3 0 013-3h6a3 3 0 013 3v12a3 3 0 01-3 3h-6a3 3 0 01-3-3V6z" />
          </svg>
          <p className="text-lg">{t('bookingHistoryEmptyState')}</p>
          <p className="text-sm">{t('bookingHistoryEmptyStateSubtext')}</p>
        </div>
      )}
    </div>
  );
};

export default ActualBookingHistoryPage;