
import React, { useState, useEffect, FormEvent } from 'react';
import { Booking, TripType } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { 
  WHEN_NEEDED_OPTIONS, 
  PACKAGE_HOURS_OPTIONS, 
  OUTSTATION_TRIP_TYPE_OPTIONS,
  ESTIMATED_USAGE_OPTIONS,
  CAR_TRANSMISSION_OPTIONS,
  CAR_MODEL_TYPE_OPTIONS
} from '../constants';

interface BookingFormProps {
  onClose: () => void;
  onSubmit: (bookingData: Omit<Booking, 'id' | 'status' | 'originalDriverId' | 'claimedByDriverId'>) => void;
  existingBooking?: Booking | null;
}

const BookingForm: React.FC<BookingFormProps> = ({ onClose, onSubmit, existingBooking }) => {
  const { t } = useLanguage();

  const [selectedTripType, setSelectedTripType] = useState<TripType>(TripType.ONE_WAY);
  const [clientName, setClientName] = useState('');
  const [pickupLocation, setPickupLocation] = useState('');
  const [dropoffLocation, setDropoffLocation] = useState('');
  
  const [whenNeeded, setWhenNeeded] = useState<'now' | 'later'>('now');
  const [dateTime, setDateTime] = useState(''); // For 'later' or Outstation
  
  const [packageHours, setPackageHours] = useState(PACKAGE_HOURS_OPTIONS[0].value); // For Round Trip
  
  const [outstationTripType, setOutstationTripType] = useState<'oneWay' | 'roundTrip'>(OUTSTATION_TRIP_TYPE_OPTIONS[0].value as 'oneWay' | 'roundTrip'); // For Outstation
  const [estimatedUsage, setEstimatedUsage] = useState(ESTIMATED_USAGE_OPTIONS[0].value); // For Outstation

  const [carTransmission, setCarTransmission] = useState<'manual' | 'auto' | 'any'>(CAR_TRANSMISSION_OPTIONS[0].value as 'manual' | 'auto' | 'any');
  const [carModelType, setCarModelType] = useState<'hatchback' | 'sedan' | 'suv' | 'any'>(CAR_MODEL_TYPE_OPTIONS[0].value as 'hatchback' | 'sedan' | 'suv' | 'any');
  
  const [notes, setNotes] = useState('');
  const [formError, setFormError] = useState<string | null>(null);

  const initializeDateTime = (bookingDateTime?: string) => {
    let initialDate;
    if (bookingDateTime) {
      initialDate = new Date(bookingDateTime);
    } else if (whenNeeded === 'later' || selectedTripType === TripType.OUTSTATION) {
      initialDate = new Date(Date.now() + 60 * 60 * 1000); // Default to 1 hour from now for 'later'
    } else {
      // For 'now', dateTime state isn't strictly needed for input, but we can clear it or set to now
      return ''; // No specific input needed for 'now' initially
    }
    // Adjust for local timezone for datetime-local input
    initialDate.setMinutes(initialDate.getMinutes() - initialDate.getTimezoneOffset());
    return initialDate.toISOString().slice(0, 16);
  };
  
  useEffect(() => {
    if (existingBooking) {
      setSelectedTripType(existingBooking.tripType || TripType.ONE_WAY);
      setClientName(existingBooking.clientName);
      setPickupLocation(existingBooking.pickupLocation);
      setDropoffLocation(existingBooking.dropoffLocation || '');
      setWhenNeeded(existingBooking.whenNeeded || 'now');
      setDateTime(initializeDateTime(existingBooking.dateTime));
      setPackageHours(existingBooking.packageHours || PACKAGE_HOURS_OPTIONS[0].value);
      setOutstationTripType(existingBooking.outstationTripType || OUTSTATION_TRIP_TYPE_OPTIONS[0].value as 'oneWay' | 'roundTrip');
      setEstimatedUsage(existingBooking.estimatedUsage || ESTIMATED_USAGE_OPTIONS[0].value);
      setCarTransmission(existingBooking.carTransmission || CAR_TRANSMISSION_OPTIONS[0].value as 'manual' | 'auto' | 'any');
      setCarModelType(existingBooking.carModelType || CAR_MODEL_TYPE_OPTIONS[0].value as 'hatchback' | 'sedan' | 'suv' | 'any');
      setNotes(existingBooking.notes || '');
    } else {
      // Reset to defaults for new booking
      setClientName('');
      setPickupLocation('');
      setDropoffLocation('');
      setWhenNeeded('now');
      setDateTime(initializeDateTime()); // Initialize for 'later' or outstation if they are default
      setPackageHours(PACKAGE_HOURS_OPTIONS[0].value);
      setOutstationTripType(OUTSTATION_TRIP_TYPE_OPTIONS[0].value as 'oneWay' | 'roundTrip');
      setEstimatedUsage(ESTIMATED_USAGE_OPTIONS[0].value);
      setCarTransmission(CAR_TRANSMISSION_OPTIONS[0].value as 'manual' | 'auto' | 'any');
      setCarModelType(CAR_MODEL_TYPE_OPTIONS[0].value as 'hatchback' | 'sedan' | 'suv' | 'any');
      setNotes('');
      setSelectedTripType(TripType.ONE_WAY); // Default to one way
    }
  }, [existingBooking]);

  // Effect to update dateTime when `whenNeeded` or `selectedTripType` changes for a new booking
   useEffect(() => {
    if (!existingBooking) { // Only for new bookings
      if (selectedTripType === TripType.OUTSTATION) {
        if (!dateTime) {
          setDateTime(initializeDateTime());
        }
      } else { // Implies selectedTripType is ONE_WAY or ROUND_TRIP
        if (whenNeeded === 'later') {
          if (!dateTime) {
            setDateTime(initializeDateTime());
          }
        } else { // whenNeeded === 'now'
          setDateTime('');
        }
      }
    }
  }, [whenNeeded, selectedTripType, existingBooking, dateTime]); // Added dateTime to dependency array for correctness if initializeDateTime can depend on it.


  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setFormError(null);

    let finalDateTime = '';
    if (selectedTripType === TripType.OUTSTATION || whenNeeded === 'later') {
        if (!dateTime) {
            setFormError(t('bookingFormErrorRequired')); // Date time required
            return;
        }
        const selectedDate = new Date(dateTime);
        if (selectedDate < new Date() && whenNeeded === 'later') {
          // Allow past date/time for outstation if it's editing existing valid one, but not for new 'later'
          if (!existingBooking || (existingBooking && new Date(existingBooking.dateTime) < new Date())) {
             setFormError(t('bookingFormErrorInvalidDateTime'));
             return;
          }
        }
        finalDateTime = selectedDate.toISOString();
    } else { // whenNeeded === 'now' for non-Outstation trips
        finalDateTime = new Date().toISOString();
    }
    
    // Basic validations
    if (!clientName.trim() || !pickupLocation.trim()) {
      setFormError(t('bookingFormErrorRequired'));
      return;
    }
    // Dropoff location is required if not a round trip
    if (selectedTripType !== TripType.ROUND_TRIP && !dropoffLocation.trim()) {
      setFormError(t('bookingFormErrorRequired'));
      return;
    }

    const bookingData: Omit<Booking, 'id' | 'status' | 'originalDriverId' | 'claimedByDriverId'> = {
      clientName,
      pickupLocation,
      dropoffLocation: selectedTripType === TripType.ROUND_TRIP ? undefined : dropoffLocation,
      dateTime: finalDateTime,
      notes,
      tripType: selectedTripType,
      whenNeeded: selectedTripType !== TripType.OUTSTATION ? whenNeeded : undefined,
      packageHours: selectedTripType === TripType.ROUND_TRIP ? packageHours : undefined,
      outstationTripType: selectedTripType === TripType.OUTSTATION ? outstationTripType : undefined,
      estimatedUsage: selectedTripType === TripType.OUTSTATION ? estimatedUsage : undefined,
      carTransmission,
      carModelType,
    };
    onSubmit(bookingData);
  };

  const formTitleId = "booking-form-title";

  const renderCommonFields = () => (
    <>
      <div>
        <label htmlFor="clientName" className="block text-sm font-medium text-gray-700 mb-1">{t('bookingFormClientName')} <span className="text-red-500">*</span></label>
        <input type="text" id="clientName" value={clientName} onChange={(e) => setClientName(e.target.value)}
          className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500" required />
      </div>
      <h3 className="text-md font-medium text-gray-700 mt-3 mb-1">{t('bookingFormChooseLocation')}</h3>
      <div>
        <label htmlFor="pickupLocation" className="sr-only">{t('bookingFormPickup')}</label>
        <input type="text" id="pickupLocation" value={pickupLocation} onChange={(e) => setPickupLocation(e.target.value)}
          placeholder={t('bookingFormPickupPlaceholder')}
          className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 mb-2.5" required />
      </div>
      {selectedTripType !== TripType.ROUND_TRIP && (
        <div>
          <label htmlFor="dropoffLocation" className="sr-only">{t('bookingFormDropoff')}</label>
          <input type="text" id="dropoffLocation" value={dropoffLocation} onChange={(e) => setDropoffLocation(e.target.value)}
            placeholder={t('bookingFormDropoffPlaceholder')}
            className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500" 
            required={true} /> {/* Changed from required={selectedTripType !== TripType.ROUND_TRIP} */}
        </div>
      )}
    </>
  );

  const renderWhenNeededAndDateTime = () => (
    <>
      <h3 className="text-md font-medium text-gray-700 mt-3 mb-1">{t('bookingFormWhenNeeded')}</h3>
      <select id="whenNeeded" value={whenNeeded} onChange={(e) => setWhenNeeded(e.target.value as 'now' | 'later')}
        className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
        {WHEN_NEEDED_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{t(opt.labelKey)}</option>)}
      </select>
      {whenNeeded === 'later' && (
        <div className="mt-2.5">
          <label htmlFor="dateTime" className="sr-only">{t('bookingFormDateTime')}</label>
          <input type="datetime-local" id="dateTime" value={dateTime} onChange={(e) => setDateTime(e.target.value)}
            className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500" required />
        </div>
      )}
    </>
  );
  
  const renderCarTypeFields = () => (
    <>
      <h3 className="text-md font-medium text-gray-700 mt-3 mb-1">{t('bookingFormCarTypeLabel')}</h3>
      <div className="grid grid-cols-2 gap-2.5">
        <div>
          <label htmlFor="carTransmission" className="sr-only">{t('bookingFormCarTransmission')}</label>
          <select id="carTransmission" value={carTransmission} onChange={(e) => setCarTransmission(e.target.value as 'manual' | 'auto' | 'any')}
            className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
            {CAR_TRANSMISSION_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{t(opt.labelKey)}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="carModelType" className="sr-only">{t('bookingFormCarModel')}</label>
          <select id="carModelType" value={carModelType} onChange={(e) => setCarModelType(e.target.value as 'hatchback' | 'sedan' | 'suv' | 'any')}
            className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
            {CAR_MODEL_TYPE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{t(opt.labelKey)}</option>)}
          </select>
        </div>
      </div>
    </>
  );

  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl shadow-lg border border-gray-200 w-full text-gray-800">
      <div className="flex justify-between items-center mb-4">
        <h2 id={formTitleId} className="text-xl font-semibold text-sky-600">
          {existingBooking ? t('bookingFormTitleEdit') : t('bookingFormTitleAdd')}
        </h2>
      </div>

      <div className="mb-4 border-b border-gray-200">
        <nav className="flex -mb-px" aria-label={t('bookingFormTripTypeLabel')}>
          {(Object.keys(TripType) as Array<keyof typeof TripType>).map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setSelectedTripType(TripType[key])}
              className={`flex-1 py-2.5 px-1 text-center border-b-2 text-sm font-medium transition-colors
                ${selectedTripType === TripType[key]
                  ? 'border-sky-500 text-sky-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              aria-current={selectedTripType === TripType[key] ? 'page' : undefined}
            >
              {t(`bookingFormTripType${key.charAt(0) + key.slice(1).toLowerCase().replace(/_/g, '')}`)}
            </button>
          ))}
        </nav>
      </div>

      {formError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-3 py-2 rounded-md mb-3 text-sm" role="alert">
          {formError}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-3">
        {renderCommonFields()}

        {selectedTripType === TripType.ONE_WAY && (
          <>
            {renderWhenNeededAndDateTime()}
            {renderCarTypeFields()}
          </>
        )}

        {selectedTripType === TripType.ROUND_TRIP && (
          <>
            {renderWhenNeededAndDateTime()}
            <div>
              <h3 className="text-md font-medium text-gray-700 mt-3 mb-1">{t('bookingFormSelectPackage')}</h3>
              <label htmlFor="packageHours" className="sr-only">{t('bookingFormPackageHours')}</label>
              <select id="packageHours" value={packageHours} onChange={(e) => setPackageHours(e.target.value)}
                className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                {PACKAGE_HOURS_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
              </select>
            </div>
            {renderCarTypeFields()}
          </>
        )}

        {selectedTripType === TripType.OUTSTATION && (
          <>
            <div>
              <h3 className="text-md font-medium text-gray-700 mt-3 mb-1">{t('bookingFormSelectTripAndUsage')}</h3>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label htmlFor="outstationTripType" className="sr-only">{t('bookingFormOutstationTripTypeLabel')}</label>
                  <select id="outstationTripType" value={outstationTripType} onChange={(e) => setOutstationTripType(e.target.value as 'oneWay' | 'roundTrip')}
                    className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                    {OUTSTATION_TRIP_TYPE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{t(opt.labelKey)}</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="estimatedUsage" className="sr-only">{t('bookingFormEstimatedUsage')}</label>
                  <select id="estimatedUsage" value={estimatedUsage} onChange={(e) => setEstimatedUsage(e.target.value)}
                    className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                    {ESTIMATED_USAGE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.labelKey ? t(opt.labelKey) : opt.label}</option>)}
                  </select>
                </div>
              </div>
            </div>
            <div className="mt-2.5">
              <label htmlFor="outstationDateTime" className="block text-sm font-medium text-gray-700 mb-1">{t('bookingFormDateTime')} <span className="text-red-500">*</span></label>
              <input type="datetime-local" id="outstationDateTime" value={dateTime} onChange={(e) => setDateTime(e.target.value)}
                className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500" required />
            </div>
            {renderCarTypeFields()}
          </>
        )}
        
        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700 mb-1 mt-3">{t('bookingFormNotes')}</label>
          <textarea id="notes" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)}
            placeholder={t('bookingFormNotesPlaceholder')}
            className="w-full p-2.5 bg-gray-50 text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500" />
        </div>

        <div className="flex justify-end space-x-3 pt-2 mt-4 border-t border-gray-200">
          <button type="button" onClick={onClose}
            className="px-5 py-2 text-sm font-medium text-gray-700 bg-gray-200 hover:bg-gray-300 rounded-lg transition-colors border border-gray-300">
            {t('bookingFormCancel')}
          </button>
          <button type="submit"
            className="px-5 py-2 text-sm font-medium text-white bg-sky-500 hover:bg-sky-600 rounded-lg transition-colors shadow hover:shadow-md">
            {existingBooking ? t('bookingFormSave') : t('bookingFormAdd')}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BookingForm;