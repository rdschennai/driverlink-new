import React from 'react';
import { Booking, BookingStatus }
from '../types';
import BookingItem from './BookingItem';
import { useLanguage } from '../contexts/LanguageContext';

interface BookingListProps {
  title: string; 
  bookings: Booking[];
  listType: 'personal' | 'available-shared' | 'my-offered' | 'my-active-rides' | 'history'; 
  activeUserId?: string; // Updated to accept undefined
  onOffer?: (bookingId: string) => void;
  onClaim?: (bookingId: string) => void;
  onAssignToSelf?: (bookingId: string) => void; 
  onCancelOffer?: (bookingId: string) => void;
  onEdit?: (booking: Booking) => void;
  onConfirmRide?: (bookingId: string) => void;
  onStartTrip?: (bookingId: string) => void;
  onUpdateToOnTrip?: (bookingId: string) => void;
  onEndTrip?: (bookingId: string) => void;
  onCompleteRide?: (bookingId: string) => void;
  onCancelBooking?: (bookingId: string) => void; 
}

const BookingList: React.FC<BookingListProps> = ({ 
  title, bookings, listType, activeUserId,
  onOffer, onClaim, onAssignToSelf, onCancelOffer, onEdit,
  onConfirmRide, onStartTrip, onUpdateToOnTrip, onEndTrip, onCompleteRide,
  onCancelBooking
}) => {
  const { t } = useLanguage();
  const uniqueListId = `booking-list-title-${title.replace(/\s+/g, '-').toLowerCase()}`;

  const isTitleRedundantWithTab = [
    t('dashboardTabPersonal'), 
    t('dashboardTabShared'), 
    t('dashboardTabAvailable'), 
    t('dashboardTabActive')     
  ].includes(title);

  if (!bookings.length) {
    return (
      <section aria-labelledby={uniqueListId}>
        <h2 id={uniqueListId} className="sr-only"> 
          {title}
        </h2>
        <div className="bg-white p-6 rounded-lg shadow text-center text-gray-500 mt-4 sm:mt-0 border border-gray-200">
          <p>{t('bookingListEmpty')}</p>
        </div>
      </section>
    );
  }

  return (
    <section aria-labelledby={uniqueListId} className="mt-4 sm:mt-0">
      <h2 id={uniqueListId} className={isTitleRedundantWithTab || listType === 'history' ? "sr-only" : "text-2xl font-semibold mb-4 text-sky-600 border-b border-gray-300 pb-2"}>
        {title} 
        {!isTitleRedundantWithTab && listType !== 'history' && ` (${bookings.length})`}
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {bookings.map((booking) => (
          <BookingItem
            key={booking.id}
            booking={booking}
            listType={listType}
            activeUserId={activeUserId} 
            onOffer={onOffer}
            onClaim={onClaim}
            onAssignToSelf={onAssignToSelf}
            onCancelOffer={onCancelOffer}
            onEdit={onEdit}
            onConfirmRide={onConfirmRide}
            onStartTrip={onStartTrip}
            onUpdateToOnTrip={onUpdateToOnTrip}
            onEndTrip={onEndTrip}
            onCompleteRide={onCompleteRide}
            onCancelBooking={onCancelBooking}
          />
        ))}
      </div>
    </section>
  );
};

export default BookingList;