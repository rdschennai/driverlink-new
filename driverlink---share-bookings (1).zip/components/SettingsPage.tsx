import React, { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useNotification } from '../contexts/NotificationContext';
import { Locale } from '../translations';

const SettingsPage: React.FC = () => {
  const { t, languageCode, setLanguageCode } = useLanguage();
  const { newBookingAlertsSoundEnabled, toggleNewBookingAlertsSound } = useNotification();

  // Local state for UI controls, synced with context for language
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [newBookingAlerts, setNewBookingAlerts] = useState(true); // General alert setting
  const [selectedDisplayLanguage, setSelectedDisplayLanguage] = useState<Locale>(languageCode);

  useEffect(() => {
    setSelectedDisplayLanguage(languageCode);
  }, [languageCode]);

  const handleLanguageChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newLangCode = event.target.value as Locale;
    setSelectedDisplayLanguage(newLangCode);
    setLanguageCode(newLangCode); 
  };

  const handleSaveSettings = () => {
    console.log("Settings to save:", {
      emailNotifications,
      smsNotifications,
      newBookingAlerts, // This is the general setting for alerts
      newBookingAlertsSound: newBookingAlertsSoundEnabled, // This is specific to sound
      language: selectedDisplayLanguage,
    });
    alert(t('settingsAlertSaved'));
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-200">
      <h2 className="text-2xl font-semibold text-sky-600 mb-6 border-b border-gray-300 pb-3">
        {t('settingsPageTitle')}
      </h2>
      
      <div className="space-y-8 text-gray-700">
        <section>
          <h3 className="text-xl font-medium text-sky-500 mb-3">{t('settingsNotificationsTitle')}</h3>
          <div className="space-y-3 p-4 bg-gray-50 rounded-md border border-gray-200">
            <div className="flex items-center justify-between">
              <label htmlFor="emailNotifications" className="text-gray-700">{t('settingsEmailNotifications')}</label>
              <input 
                type="checkbox" 
                id="emailNotifications" 
                className="form-checkbox h-5 w-5 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-opacity-50" 
                checked={emailNotifications}
                onChange={(e) => setEmailNotifications(e.target.checked)}
              />
            </div>
            <div className="flex items-center justify-between">
              <label htmlFor="smsNotifications" className="text-gray-700">{t('settingsSmsNotifications')}</label>
              <input 
                type="checkbox" 
                id="smsNotifications" 
                className="form-checkbox h-5 w-5 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-opacity-50"
                checked={smsNotifications}
                onChange={(e) => setSmsNotifications(e.target.checked)}
              />
            </div>
             <div className="flex items-center justify-between">
              <label htmlFor="newBookingAlerts" className="text-gray-700">{t('settingsNewBookingAlerts')}</label>
              <input 
                type="checkbox" 
                id="newBookingAlerts" 
                className="form-checkbox h-5 w-5 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-opacity-50" 
                checked={newBookingAlerts}
                onChange={(e) => setNewBookingAlerts(e.target.checked)}
              />
            </div>
            <div className="flex items-center justify-between pt-2 border-t border-gray-300 mt-2">
              <label htmlFor="newBookingAlertsSound" className="text-gray-700">{t('settingsPlaySoundForNewBookings')}</label>
              <input 
                type="checkbox" 
                id="newBookingAlertsSound" 
                className="form-checkbox h-5 w-5 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-opacity-50" 
                checked={newBookingAlertsSoundEnabled}
                onChange={toggleNewBookingAlertsSound}
              />
            </div>
          </div>
        </section>

        <section>
          <h3 className="text-xl font-medium text-sky-500 mb-3">{t('settingsLanguageTitle')}</h3>
          <div className="p-4 bg-gray-50 rounded-md border border-gray-200">
            <label htmlFor="languageSelect" className="block text-sm font-medium text-gray-600 mb-1">{t('settingsSelectLanguage')}</label>
            <select 
              id="languageSelect" 
              className="w-full p-3 bg-white text-gray-800 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
              value={selectedDisplayLanguage}
              onChange={handleLanguageChange}
            >
              <option value="en">English</option>
              <option value="ta">தமிழ் (Tamil)</option>
            </select>
          </div>
        </section>

         <div className="mt-8 pt-6 border-t border-gray-300">
             <button 
                onClick={handleSaveSettings}
                className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded-lg shadow hover:shadow-md transition-colors duration-300"
                aria-label={t('settingsSaveButton')}
            >
                {t('settingsSaveButton')}
            </button>
         </div>
      </div>
    </div>
  );
};

export default SettingsPage;